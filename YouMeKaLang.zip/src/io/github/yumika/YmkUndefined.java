package io.github.yumika;

class YmkUndefined {
  @Override
  public String toString() {
    return "undefined";
  }
}
