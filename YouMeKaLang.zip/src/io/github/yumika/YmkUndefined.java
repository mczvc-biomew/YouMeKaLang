package io.github.yumika;

class YmkUndefined {

  static final YmkUndefined INSTANCE = new YmkUndefined();
  @Override
  public String toString() {
    return "undefined";
  }
}
