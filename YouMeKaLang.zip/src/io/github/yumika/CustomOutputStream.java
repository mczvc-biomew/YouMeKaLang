package io.github.yumika;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;

public class CustomOutputStream extends OutputStream {
  private JTextArea textArea;
  private PrintWriter inWriter;

  public CustomOutputStream(JTextArea textArea) throws IOException {
    this.textArea = textArea;
    PipedInputStream pineIn = new PipedInputStream();
    inWriter = new PrintWriter(new PipedOutputStream(pineIn), true);

    textArea.addKeyListener(new KeyAdapter() {
      private StringBuffer line = new StringBuffer();

      @Override
      public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (c == KeyEvent.VK_ENTER) {
          inWriter.println(line);
          line.setLength(0);
        } else if (c == KeyEvent.VK_BACK_SPACE) {
          if (!line.isEmpty()) {
            line.setLength(line.length() - 1);
          }
        } else if (c == KeyEvent.VK_ESCAPE) {
          System.exit(0);
        } else if (!Character.isISOControl(c)) {
          line.append(e.getKeyChar());
        }
      }
    });
  }

  @Override
  public void write(int b) throws IOException {
    textArea.append(String.valueOf((char)b));
    textArea.setCaretPosition(textArea.getDocument().getLength());
  }
}
