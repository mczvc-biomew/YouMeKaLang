package io.github.yumika;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

class Resolver implements Expr.Visitor<Void>, Stmt.Visitor<Void> {
  private final Interpreter interpreter;
  private final Stack<Map<String, Boolean>> scopes = new Stack<>();

  private FunctionType currentFunction = FunctionType.NONE;

  Resolver(Interpreter interpreter) { this.interpreter = interpreter; }

  private enum FunctionType {
    NONE,
    // function-type-method
    FUNCTION,
    // function-type-initializer
    INITIALIZER,
    METHOD,
    LAMBDA
  }

  private enum ClassType {
    NONE,
    CLASS,
    SUBCLASS
  }

  private ClassType currentClass = ClassType.NONE;

  void resolve(List<Stmt> statements) {
    for (Stmt statement : statements) {
      resolve(statement);
    }
  }

  @Override
  public Void visitBlockStmt(Stmt.Block stmt) {
    beginScope();
    resolve(stmt.statements);
    endScope();
    return null;
  }

  @Override
  public Void visitClassStmt(Stmt.Class stmt) {
    ClassType enclosingClass = currentClass;
    currentClass = ClassType.CLASS;

    // set-current-class
    declare(stmt.name);
    define(stmt.name);

    // inherit-self
    if (stmt.superclass != null &&
        stmt.name.lexeme.equals(stmt.superclass.name.lexeme)) {
      YouMeKa.error(stmt.superclass.name,
          "A class can't inherit from itself.");
    }

    if (stmt.superclass != null) {
      // set-current-subclass
      currentClass = ClassType.SUBCLASS;
      resolve(stmt.superclass);
    }

    // Inheritance begin-super-scope
    if (stmt.superclass != null) {
      beginScope();
      scopes.peek().put("super", true);
    }

    // resolve-methods
    // resolver-begin-this-scope
    beginScope();
    scopes.peek().put("this", true);

    for (Stmt.Function method : stmt.methods) {
      FunctionType declaration = FunctionType.METHOD;

      if (method.name.lexeme.equals("init")) {
        declaration = FunctionType.INITIALIZER;
      }

      resolveFunction(method, declaration);
    }

    // resolver-end-this-scope
    endScope();

    // Inheritance end-super-scope
    if (stmt.superclass != null) endScope();

    // restore-current-class
    currentClass = enclosingClass;

    return null;
  }

  @Override
  public Void visitExpressionStmt(Stmt.Expression stmt) {
    resolve(stmt.expression);
    return null;
  }

  @Override
  public Void visitFunctionStmt(Stmt.Function stmt) {
    declare(stmt.name);
    define(stmt.name);

    // pass-function-type
    resolveFunction(stmt, FunctionType.FUNCTION);
    return null;
  }

  @Override
  public Void visitIfStmt(Stmt.If stmt) {
    resolve(stmt.condition);
    resolve(stmt.thenBranch);
    if (stmt.elseBranch != null) resolve(stmt.elseBranch);
    return null;
  }

  @Override
  public Void visitPrintStmt(Stmt.Print stmt) {
    resolve(stmt.expression);
    return null;
  }

  @Override
  public Void visitReturnStmt(Stmt.Return stmt) {
    if (currentFunction == FunctionType.NONE) {
//      YouMeKa.error(stmt.keyword, "Can't return from top-level code.");
    }

    if (stmt.value != null) {
      // Classes return-in-initializer
      if (currentFunction == FunctionType.INITIALIZER) {
        YouMeKa.error(stmt.keyword, "Can't return a value from an initializer.");
      }

      resolve(stmt.value);
    }
    return null;
  }

  @Override
  public Void visitVarStmt(Stmt.Var stmt) {
    declare(stmt.name);
    if (stmt.initializer != null) {
      resolve(stmt.initializer);
    }
    define(stmt.name);
    return null;
  }

  @Override
  public Void visitWhileStmt(Stmt.While stmt) {
    resolve(stmt.condition);
    resolve(stmt.body);
    return null;
  }

  @Override
  public Void visitArrayAssignExpr(Expr.ArrayAssign expr) {
    resolve(expr.array);
    resolve(expr.index);
    resolve(expr.value);
    return null;
  }

  @Override
  public Void visitArrayExpr(Expr.ArrayLiteral expr) {
    for (Expr element : expr.elements) {
      resolve(element);
    }
    return null;
  }

  @Override
  public Void visitArrayIndexExpr(Expr.ArrayIndex expr) {
    resolve(expr.array);
    resolve(expr.index);
    return null;
  }

  @Override
  public Void visitAssignExpr(Expr.Assign expr) {
    resolve(expr.value);
    resolveLocal(expr, expr.name);
    return null;
  }

  @Override
  public Void visitBinaryExpr(Expr.Binary expr) {
    resolve(expr.left);
    resolve(expr.right);
    return null;
  }

  @Override
  public Void visitBlockExpr(Expr.Block expr) {
    resolve(expr.statements);
    return null;
  }

  @Override
  public Void visitCallExpr(Expr.Call expr) {
    resolve(expr.callee);

    for (Expr argument : expr.arguments) {
      resolve(argument);
    }

    return null;
  }

  @Override
  public Void visitGetExpr(Expr.Get expr) {
    resolve(expr.object);
    return null;
  }

  @Override
  public Void visitGroupingExpr(Expr.Grouping expr) {
    resolve(expr.expression);
    return null;
  }

  @Override
  public Void visitLambdaExpr(Expr.Lambda expr) {
    FunctionType enclosingFunction = currentFunction;
    currentFunction = FunctionType.LAMBDA;

    beginScope();
    for (Token param : expr.params) {
      declare(param);
      define(param);
    }
    resolve(expr.body);
    endScope();

    currentFunction = enclosingFunction;
    return null;
  }

  @Override
  public Void visitListComprehensionExpr(Expr.ListComprehension expr) {
    resolve(expr.iterable);
    if (expr.condition != null)
      resolve(expr.condition);
    resolve(expr.elementExpr);
    return null;
  }

  @Override
  public Void visitLiteralExpr(Expr.Literal expr) { return null; }

  @Override
  public Void visitLogicalExpr(Expr.Logical expr) {
    resolve(expr.left);
    resolve(expr.right);
    return null;
  }

  @Override
  public Void visitObjectLiteralExpr(Expr.ObjectLiteral expr) {
    Map<String, Expr> values = ((Expr.ObjectLiteral)expr).properties;
    for (Map.Entry<String, Expr> entry : values.entrySet()) {
      resolve(entry.getValue());
    }

    return null;
  }

  @Override
  public Void visitSetExpr(Expr.Set expr) {
    resolve(expr.value);
    resolve(expr.object);
    return null;
  }

  @Override
  public Void visitSuperExpr(Expr.Super expr) {
    // invalid-super
    if (currentClass == ClassType.NONE) {
      YouMeKa.error(expr.keyword,
          "Can't use 'super' outside of a class.");
    } else if (currentClass != ClassType.SUBCLASS) {
      YouMeKa.error(expr.keyword,
          "Can't use 'super' in a class with no superclass.");
    }

    resolveLocal(expr, expr.keyword);
    return null;
  }

  @Override
  public Void visitThisExpr(Expr.This expr) {
    // this-outside-of-class
//    if (currentClass == ClassType.NONE) {
//      YouMeKa.error(expr.keyword, "Can't use 'this' outside of a class.");
//      return null;
//    }

    resolveLocal(expr, expr.keyword);
    return null;
  }

  @Override
  public Void visitUnaryExpr(Expr.Unary expr) {
    resolve(expr.right);
    return null;
  }

  public Void visitUndefinedExpr(Expr.Undefined expr) {
    return null;
  }

  @Override
  public Void visitVariableExpr(Expr.Variable expr) {
    if (!scopes.isEmpty() &&
    scopes.peek().get(expr.name.lexeme) == Boolean.FALSE) {
      YouMeKa.error(expr.name,
          "Can't read local variable in its own initializer.");
    }

    resolveLocal(expr, expr.name);
    return null;
  }

  private void resolve(Stmt stmt) { stmt.accept(this); }
  private void resolve(Expr expr) { expr.accept(this); }
  private void resolveFunction(
      Stmt.Function function, FunctionType type) {
    FunctionType enclosingFunction = currentFunction;
    currentFunction = type;

    beginScope();
    for (Token param : function.params) {
      declare(param);
      define(param);
    }
    resolve(function.body);
    endScope();
    // restore-current-function
    currentFunction = enclosingFunction;
  }

  private void beginScope() { scopes.push(new HashMap<String, Boolean>()); }
  private void endScope() { scopes.pop(); }
  private void declare(Token name) {
    if (scopes.isEmpty()) return;

    Map<String, Boolean> scope = scopes.peek();
    // duplicate-variable
    if (scope.containsKey(name.lexeme)) {
      YouMeKa.error(name,
          "Already declared in this scope.");
    }

    scope.put(name.lexeme, false);
  }

  private void define(Token name) {
    if (scopes.isEmpty()) return;
    scopes.peek().put(name.lexeme, true);
  }

  private void resolveLocal(Expr expr, Token name) {
    for (int i = scopes.size() - 1; i >= 0; i--) {
      if (scopes.get(i).containsKey(name.lexeme)) {
        interpreter.resolve(expr, scopes.size() - 1 - i);
      }
    }
  }

}
