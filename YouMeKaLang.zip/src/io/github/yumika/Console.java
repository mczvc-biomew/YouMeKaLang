package io.github.yumika;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class Console extends JFrame {
  private JTextArea textOutput;
  private PrintStream printStream;

  public Console() throws IOException {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception ex) {
      System.err.println("Failed to initialize theme. Using fallback.");
    }

    setTitle("YouMeKa Basic 0.0.1");
    setPreferredSize(new Dimension(800, 400));
    textOutput = new JTextArea(5, 10);
    textOutput.setFont(new Font("Monospaced", Font.BOLD, (int) 12));
    textOutput.setBackground(Color.BLACK);
    textOutput.setForeground(Color.WHITE);
    textOutput.setCaretColor(Color.YELLOW);

    JScrollPane scrollPane = new JScrollPane(textOutput, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    printStream = new PrintStream(new CustomOutputStream(textOutput));
    System.setOut(printStream);
    System.setErr(printStream);

    add(scrollPane);

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setVisible(true);
  }
}
