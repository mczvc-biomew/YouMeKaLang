package io.github.yumika;

import java.lang.reflect.Array;

class YmkArray {
  private final Object[] array;

  YmkArray(Object[] array) {
    this.array = array;
  }

  Object get(int index) {
    return this.array[index];
  }
}
